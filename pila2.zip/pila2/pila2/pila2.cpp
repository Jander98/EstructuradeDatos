// pila2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

#include "pilaa.h"
using namespace std;


int main()
{
    //clrscr();

    pilaa s;
    DATA_TYPE d;

    for (d=0; d<=100; d++) s.put(d);

    while ( ! s.empty() )
	cout << (DATA_TYPE)s.get() << " ";

    cout << "\nPara terminar presione <Enter>...";
    cin.get();
    return 0;
}