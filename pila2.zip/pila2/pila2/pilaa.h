#pragma once
#include <iostream>
//#include <conio.h>

using namespace std;

/* tipo de dato que contendr� la lista */
typedef int DATA_TYPE;

// declaraci�n de estructura nodo
struct nodo {
	DATA_TYPE data;
	nodo *next;
};

class pilaa {

    // atributos
    int ITEMS;    /* n�mero de elementos en la lista */
    int ITEMSIZE; /* tama�o de cada elemento */
    nodo *SP;     /* puntero de lectura/escritura */

public:
    // constructor
    pilaa();

    // destructor
	~pilaa();

    /* agregar componente a la lista */
    DATA_TYPE put(DATA_TYPE valor);
   
    int empty();


    /* retirar elemento de la lista */
    DATA_TYPE get();

}; // fin de la clase StackDin


