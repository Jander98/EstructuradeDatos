#include "StdAfx.h"
#include "pilaa.h"


pilaa::pilaa(): SP(NULL), ITEMS(0), ITEMSIZE(sizeof(DATA_TYPE)) 
{
}


pilaa::~pilaa()
{
}
DATA_TYPE pilaa:: put(DATA_TYPE valor)
    {
	nodo *temp;

	temp = new nodo;
	if (temp == NULL) return -1;

	temp->data = valor;
	temp->next = SP;
	SP = temp;
	ITEMS ++;
	return valor;
    }
int pilaa::empty() { return ITEMS == 0; }

DATA_TYPE pilaa:: get()
    {
	nodo *temp;
	DATA_TYPE d;

	if ( empty() ) return -1;

	d = SP->data;
	temp = SP->next;
	if (SP) delete SP;
	SP = temp;
	ITEMS --;
	return d;
    }
