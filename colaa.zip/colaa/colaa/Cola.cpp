#include "StdAfx.h"
#include "Cola.h"
#define max 100
#include <iostream>
using namespace std;

Cola::Cola(void)
{ini=0;fin=0;
}


Cola::~Cola(void)
{
}
bool Cola::ColaVacia(void)
{
	bool b_aux;
	if(ini==fin)
		b_aux=true;
	else
		b_aux=false;

	return b_aux;


}
bool Cola::Encolar(int x)

{bool error;
if(fin==max)
	error=true;
else
	{error=false;
    info[fin]=x;
	fin++;
}
	return error;

}
bool Cola::PrimeroCola(int &x)
{bool error;
if(ColaVacia())
	error=true;
else
{	error=false;
x=info[ini];
}
return error;

}
bool Cola::desencolar(void)
{
	bool error;
	if(ColaVacia())
		error=true;
	else
	{	error=false;
	ini++;
}
return error;


}
int Cola::siguiente(int ind)
{ return(ind+1)%max;



}
void Cola::mostrar()
{
	for (int i=ini;i<fin;i++)
		cout<<"["<<info[i]<<"]="<<endl;
	cout<<endl<<endl;
}

