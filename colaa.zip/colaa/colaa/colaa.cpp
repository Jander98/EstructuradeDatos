// colaa.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Cola.h"
#include "conio.h"
#include <iostream>
#define max 100
using namespace std;

void main()

{int  info[max];
int ini,fin,op,m,p;
Cola c;

do {
		cout<<"Ingrese el valor de la cola: ";
		cin>>m;
	} while ((m>max) || (m<=0));
	  
	do{
		cout<<"-----       M E N U        -----"<<endl;
		cout<<"|1.- Encolar.                  |"<<endl;
		cout<<"|2.- PrimeroCola.              |"<<endl;
		cout<<"|3.- desencolar.               |"<<endl;
		cout<<"|4.- Mostrar.                  |"<<endl;
		cout<<"|0.- Salir                     |"<<endl;
		cout<<"--------------------------------"<<endl;
		cout<<" Elija una opcion"<<endl;
		cin>>op;
		switch(op){
		case 1:
			if(c.Encolar(m)==true)
				cout<<"la cola esta llena"<<endl;
			else
				cout<<"se agrego el valor"<<endl;


			break;
		case 2:
			if(c.PrimeroCola(p)==false){
				cout<<"El numero es: "<<p;
			}else{
				cout<<"Cola Vacia"<<endl;
			}
			
			break;
		case 3:
			if(c.desencolar()==false){
				cout<<"Se elimino el Valor"<<endl;
			}else{
				cout<<"Cola Vacia"<<endl;
			}
			
			break;
		case 4:
			c.mostrar();
			break;
		case 0: 
			cout<<"Salir"<<endl;
			break;
		default:
			cout<<"Error: Opcion no valida..."<<endl;
			break;
		}
}while(op!=0);
	system("cls");













getch();

}