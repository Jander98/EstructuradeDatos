#pragma once
#define max 100
class Cola
{private:

int  info[max];
int ini,fin;
public:
	Cola(void);
	~Cola(void);
	bool Encolar(int x);
	bool desencolar(void);
	bool PrimeroCola(int &x);
	bool ColaVacia(void);
	int siguiente(int ind);
	void mostrar();
};

